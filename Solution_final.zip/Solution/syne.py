import cv2
import numpy as np
import os
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn import grid_search
import xgboost as xgb
import pickle
from sklearn.externals import joblib


sift = cv2.xfeatures2d.SIFT_create()

train_path = ['A/sad','A/happy']

def load_images():
	trainList = {}
	testList = {}
	count = 0
	for i in train_path:
		new_class = i.split("/")[-1]		
		image_file = os.listdir(i)
		new_size = len(image_file)*0.8
		imagesList = []
		trainList[new_class] = []
		testList[new_class]= []
		for img in image_file:
			img_file = os.path.join(i,img)
			im = cv2.imread(img_file,0)
			imagesList.append(im)
			count += 1
		for i in range(len(imagesList[:int(new_size)])):
			trainList[new_class].append(imagesList[i])
		for i in range(len(imagesList[int(new_size):])):
			testList[new_class].append(imagesList[i])
	return trainList,testList

trainData,testData = load_images()
num_images = 0
num_images += len(trainData['sad']) + len(trainData['happy'])
# ==================================   Bag of Visual Words  =================================================================
desc_list = []
trainLabels = np.array([])
labelCount = 0
name_dict = {}
for new_class,imlist in trainData.items():
	name_dict[str(labelCount)] = new_class
	for img in imlist:
		trainLabels = np.append(trainLabels,labelCount)
		kp,des = sift.detectAndCompute(img,None)
		desc_list.append(des)
	labelCount += 1

desc_vStack = np.concatenate(desc_list,axis=0)
# ================================	perform kmeans  =======================================
n_clusters = 28
kmeans = KMeans(n_clusters=n_clusters,random_state=0)
desc_predict = kmeans.fit_predict(desc_vStack)
file_image2 = "kmeans_model.pkl"  # serialize model with pickle
with open(file_image2, "w") as f:
    joblib.dump(desc_predict, file_image2)
# ==================================== BOVW end =============================


# Generate histogram corresponding to frequency of each cluster(visual word)
# like there are 50 pixels with 250 gray levels histogram is orderless(distribution)
def gen_hist(n_clusters,num_images,desc_list,desc_predict):
	hist = np.array([np.zeros(n_clusters) for i in range(num_images)])
	init = 0
	for i in range(num_images):
		for j in range(len(desc_list[i])):
			idx = desc_predict[init+j]
			hist[i][idx] += 1
		init += 1

	return hist

hist = gen_hist(n_clusters,num_images,desc_list,desc_predict)
scale = StandardScaler().fit(hist)
hist = scale.transform(hist)
model = xgb.XGBClassifier()
# model = xgb.XGBClassifier(learning_rate =0.1,\
#  n_estimators=1000,\
#  max_depth=5,\
#  min_child_weight=1,\
#  gamma=0,\
#  subsample=0.8,\
#  colsample_bytree=0.8,\
#  objective= 'binary:logistic',\
#  nthread=4,\
#  scale_pos_weight=1,\
#  seed=27)
# param_grid = {
#         'scale_pos_weight' : [2, 2.5, 3, 3.5],
#         'n_estimators': [100, 150, 200],
#     }

    
# model = grid_search.GridSearchCV(estimator=clf, param_grid=param_grid, n_jobs=5, cv=3, verbose=20, scoring = 'f1_micro')

model.fit(hist,trainLabels)

file_image = "image_model.pkl"  # serialize model with pickle
with open(file_image, "w") as f:
    joblib.dump(model, file_image)
# s = pickle.dumps(model)
# clf2 = pickle.loads(s)
model = joblib.load(file_image)

predict = []
orig = []
predi = []
predFinal = []

for new_class,imlist in testData.items():
	for img in imlist:
		kp,des = sift.detectAndCompute(img,None)
		# Generate vocab for each image
		vocab = np.array([0 for i in range(n_clusters)])
		pred = kmeans.predict(des)
		for i in pred:
			vocab[i] += 1		
		vocab = scale.transform(vocab.reshape(1,-1))
		res_class = model.predict(vocab)
		finalOut = model.predict_proba(vocab)
		predFinal.append(finalOut[0][0])
		predi.append(name_dict[str(int(res_class[0]))])
		orig.append(new_class)

print ('original ',orig)
print ('predicted ',predFinal)
print ('accuracy_score ',accuracy_score(orig,predi))