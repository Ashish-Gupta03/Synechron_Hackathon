import os
import cv2
import pandas as pd
import numpy as np
from sklearn.externals import joblib
from sklearn.feature_extraction.text import TfidfVectorizer,TfidfTransformer,CountVectorizer
from data_preprocessing import tokenize
from model import  tfidf_vectorizer_test_x,tfidf_vectorizer_music_x
from statistics import mean

folder = os.getcwd()
sift = cv2.xfeatures2d.SIFT_create()

stri = '/KA-HA1_A.jpg'

testImg = folder + stri
im = cv2.imread(testImg,0)
kp,des = sift.detectAndCompute(im,None)
desc_predict = joblib.load('kmeans_model.pkl')
scale = joblib.load('scalar.pkl')

if stri[4:6] == 'HA' or stri[4:6] == 'SU' or stri[4:6] == 'NE':
	i = 100
else:
	i = 0



hist = np.array([np.zeros(28) for i in range(1)])
for j in range(len(des)):	
	idx = desc_predict[i+j]
	hist[0][idx] += 1
hist = scale.transform(hist)
predImg = 0

test = pd.read_csv('testSyne.csv')
testTwitter = list(test['description'][0])
testTwitterLabel = 0

testVoice = folder + '/Audio20s17.aac'
df = pd.read_csv('music.csv')
testMusic = df['colummn']


# testTwitter = tfidf_vectorizer.transform(test['description'])
# print ('testTwitter ',testTwitter.toarray()[0])


algorithms = ['tfidf_vectorizer_model.pkl', 'image_model.pkl', 'tfidf_vectorizer_model.pkl' ] #for classification

predictions = []#matrix(row_length=len(target), column_length=len(algorithms))

for i,algorithm in enumerate(algorithms):
	if i == 0:
		algorithm1 = joblib.load(algorithm)
		print ('val is ',tfidf_vectorizer_music_x.toarray())
		predictions.append(float(algorithm1.predict_proba(tfidf_vectorizer_test_x.toarray()[0])[0][0]))
		print ('predictions1 ',predictions[0])
	elif i == 1:
		algorithm1 = joblib.load(algorithm)
		predictions.append(algorithm1.predict_proba(hist)[0][0])
		print ('predictions2 ',predictions[1])
	else:
		algorithm1 = joblib.load(algorithm)
		print ('val2 is ',tfidf_vectorizer_music_x.toarray())
		predictions.append(float(algorithm1.predict_proba(tfidf_vectorizer_music_x.toarray()[0])[0][0]))
		print ('predictions3 ',predictions[2])




print ('predictions ',predictions)
weights = [0.35,0.35,0.2,0.1] #length is equal to len(algorithms)
final_predictions = []
sum = 0
for row_number in range(len(predictions)):
    sum += predictions[row_number]*weights[row_number]
sum += 0.2*weights[3]
# meanN = mean(final_predictions)
print ('final prediction ',sum)    
# print ('meanN ',meanN)    