#!/bin/bash

# This script first converts the given .aac speech file to .flac file and then invokes the Google Speech API to convert it to text

# Conversion of .aac file specified as argument 1 to speech.flac
ffmpeg -hide_banner -i "$1" -y -f flac -ar 16000 -ac 1 speech.flac

echo -----File conversion successful. Converting speech to text-----

# Invoke script to convert speech to text using Google Speech API
python quickstart.py
