from sklearn.cluster import KMeans
import pandas as pd

df = pd.read_csv('training.csv')
x= []
for i in df['clusterid']:
	x.append(i)

print (x)	
df = df.drop('classid',axis=1)
df = df.drop('clusterid',axis=1)
print (df.columns)
km = KMeans(n_clusters = 4)
new_df = km.fit_predict(df)
print (new_df)
s = pd.Series(new_df).reset_index()
s.columns = ['column1','column2']
s.to_csv('foo.csv')

df['cluster_pred'] = s['column2']
df.to_csv('trinedCluster.csv')